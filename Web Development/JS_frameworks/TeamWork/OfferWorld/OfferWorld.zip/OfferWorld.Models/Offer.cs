﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfferWorld.Models
{
    public class Offer
    {
        public int OfferId { get; set; }

        public virtual User User { get; set; }

        public virtual Item Item { get; set; }
    }
}
