﻿[
	{
		"id": 1,
		"title": "JavaScript Frameworks Course in Telerik Academy",
		"content": "The JavaScript Frameworks Course in Telerik Academy is just about to start. Don't miss it, you will be sorry!",
		"category": "web",
		"comments": [
			{ "from": "Doncho Minkov", "text": "Cool!" },
			{ "from": "Ivan Ivanov", "text": "We expect more homeworks this time!" }
		]
	}, {
		"id": 2,
		"title": "Web applications with ASP.NET MVC",
		"content": "Learn how to develop near-to-unearthly web applications using the platform ASP.NET MVC",
		"category": "web",
		"comments": [
			{ "from": "Doncho Minkov", "text": "Cool!" },
			{ "from": "Ivan Ivanov", "text": "We expect more homeworks this time!" }
		]
	}, {
		"id": 3,
		"title": "Windows 8 store applications with HTML",
		"content": "Telerik Academy is about to launch the new course for Windows 8 Store applications this summer. The course will cover the basics for creating ",
		"category": "windows",
		"comments": [{ "from": "Doncho Minkov", "text": "Cool!" }]
	}
]