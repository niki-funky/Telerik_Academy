user: admin
pass: 123456

has admin rights