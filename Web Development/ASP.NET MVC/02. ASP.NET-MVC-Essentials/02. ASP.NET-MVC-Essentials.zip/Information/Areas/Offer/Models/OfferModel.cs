﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Information.Areas.Offer.Models
{
    public class OfferModel
    {
        public List<string> OfferTitles { get; set; }
    }
}