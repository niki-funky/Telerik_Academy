﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Information.Models
{
    public class TVmodel
    {
        public List<string> TvTitles { get; set; }
        public DateTime Date { get; set; }
    }
}