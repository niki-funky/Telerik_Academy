﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Information.Models
{
    public class NewsModel
    {
        public List<string> NewsTitles { get; set; }
    }
}