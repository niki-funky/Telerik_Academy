﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LaptopSystem.Web.Models
{
    public class SubmitSearchModel
    {
        public string ModelSearch { get; set; }

        public string ManufSearch { get; set; }

        public decimal PriceSearch { get; set; } 
    }
}